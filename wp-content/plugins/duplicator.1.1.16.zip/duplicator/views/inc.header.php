<?php function duplicator_header($title) { ?>
<!-- !!DO NOT CHANGE OR EDIT PRODUCT NAME!!
If your interested in Private Label Rights please contact us for 
customizations to product labeling: lifeinthegrid.com	-->
	<h1><?php echo $title ?><br/></h1>
<?php } ?>