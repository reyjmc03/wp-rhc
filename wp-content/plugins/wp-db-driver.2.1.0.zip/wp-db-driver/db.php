<?php

_deprecated_file( __FILE__, '2.0', dirname( __FILE__ ) . '/wp-content/db.php', 'There is a new db.php file.' );

require( dirname( __FILE__ ) . '/inc/db-driver.php' );