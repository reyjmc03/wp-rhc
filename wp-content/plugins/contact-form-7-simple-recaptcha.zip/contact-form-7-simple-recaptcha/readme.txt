=== Contact Form 7 Simple Recaptcha ===
Contributors: 247wd
Donate link: http://wordpress.org/plugins/contact-form-7-simple-recaptcha
Tags: recaptcha, new recaptcha, contact form 7, no captcha
Requires at least: 4.1.2
Tested up to: 4.4.1
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add No CAPTCHA reCAPTCHA to Contact Form 7

== Description ==

Latest version of Contact Form 7 implemented similar captcha.<br>
No reason to install additional plugin.<br>

Add No CAPTCHA reCAPTCHA to Contact Form 7.<br>
Tested with Contact Form 7 version 4.3.1 and WordPress version 4.4.1<br>
A significant number of your users can now attest they are human without having to solve a CAPTCHA.<br>
With just a single click they'll confirm they are not a robot.<br>
Configure plugin from Settings => CF7 Simple Recaptcha.<br>
After configuration, add [cf7sr-simple-recaptcha] to any Contact Form 7.<br>
To allow submitting form multiple times on same page, edit Contact Form => Additional Settings => and add: on_sent_ok: "grecaptcha.reset();"<br>
In case it does not work, just deactivate.<br>

== Installation ==

1. Upload the entire contents of the zip file to your plugin directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure plugin from Settings => CF7 Simple Recaptcha
== Screenshots ==

